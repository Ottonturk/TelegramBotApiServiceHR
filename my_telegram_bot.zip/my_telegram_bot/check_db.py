import sqlite3

def fetch_cv_records():
    # Подключаемся к базе данных
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    # Выполняем запрос на получение всех записей из таблицы cv
    cursor.execute('SELECT * FROM cv')
    rows = cursor.fetchall()
    
    # Закрываем соединение с базой данных
    conn.close()
    
    return rows

if __name__ == '__main__':
    cv_records = fetch_cv_records()
    for record in cv_records:
        print(record)
