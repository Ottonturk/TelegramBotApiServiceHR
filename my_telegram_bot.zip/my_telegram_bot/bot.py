import os
import telebot
from telebot import types
from config import BOT_TOKEN
from config import ADMIN_USERNAME
import database

# Инициализация базы данных
database.init_db()

# Путь к папке для сохранения CV
CV_DIR = 'CV'

# Создаем папку, если ее нет
if not os.path.exists(CV_DIR):
    os.makedirs(CV_DIR)

# Создаем экземпляр бота
bot = telebot.TeleBot(BOT_TOKEN)

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Hi! Please send me your CV :)")

# Хранение временных данных регистрации
user_data = {}

# Обработчик команды /register
@bot.message_handler(commands=['register'])
def register(message):
    if message.from_user.username == ADMIN_USERNAME:
        msg = bot.reply_to(message, "Enter Full name of the user:")
        bot.register_next_step_handler(msg, process_full_name_step)
    else:
        bot.reply_to(message, "You do not have permission to do it.")

def process_full_name_step(message):
    chat_id = message.chat.id
    full_name = message.text
    user_data[chat_id] = {'full_name': full_name}
    msg = bot.reply_to(message, "Enter email of the new user:")
    bot.register_next_step_handler(msg, process_email_step)

def process_email_step(message):
    chat_id = message.chat.id
    email = message.text
    user_data[chat_id]['email'] = email
    msg = bot.reply_to(message, "Enter password of the new user:")
    bot.register_next_step_handler(msg, process_password_step)

def process_password_step(message):
    chat_id = message.chat.id
    full_name = user_data[chat_id]['full_name']
    email = user_data[chat_id]['email']

    password = message.text
 
    #role = user_data[chat_id]['role_id']
    #telegram_id = message.from_user.id
    #username = message.from_user.username
    
    bot.reply_to(message, "user role of the new user: 1 - ADMI, 2 - HR")

    #Все роли времено = 2:  
    role = 2 

    # Сохраняем пользователя в базу данных
    database.save_user(chat_id, message.from_user.username, full_name, email, password, role)
    
    bot.reply_to(message, "New user registered!")

# Обработчик команды /addprofession
@bot.message_handler(commands=['addprofession'])
def add_profession(message):
    if message.from_user.username == ADMIN_USERNAME:
        msg = bot.reply_to(message, "Enter new profession:")
        bot.register_next_step_handler(msg, process_profession_step)
    else:
        bot.reply_to(message, "You do not have rights to execute the command.")

def process_profession_step(message):
    profession_name = message.text

    # Сохраняем профессию в базу данных
    database.save_profession(profession_name)
    
    bot.reply_to(message, f"New profession '{profession_name}' succesfully added!")



# Обработчик документов
@bot.message_handler(content_types=['document'])
def handle_document(message):
    document = message.document
    file_id = document.file_id
    file_name = document.file_name
    user_id = message.from_user.id
    username = message.from_user.username

    # Получаем файл
    file_info = bot.get_file(file_id)
    downloaded_file = bot.download_file(file_info.file_path)

    # Сохраняем файл
    file_path = os.path.join(CV_DIR, file_name)
    with open(file_path, 'wb') as new_file:
        new_file.write(downloaded_file)

    # Временно установим profession_id как NULL, так как профессии еще не указаны пользователем
    profession_id = None

    # Сохраняем информацию о CV в базу данных
    database.save_cv(user_id, username, file_name, file_path, profession_id)

    bot.reply_to(message, f'Thank you for that! Your CV saved as {file_name}. We contact you soon.')

# Запускаем бота с использованием Long Polling
bot.polling()

