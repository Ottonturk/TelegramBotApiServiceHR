from flask import Flask, request, render_template, redirect, url_for, session, flash, jsonify
import database

import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import logging
import os


app = Flask(__name__)
app.secret_key = 'supersecretkey'

 


# Инициализация базы данных
database.init_db()


def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn


# Initialize roles
#add_role('ADMIN')
#add_role('HR')


def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return wrapper

def role_required(role):
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'user_role' not in session or session['user_role'] != role:
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return wrapper
    return decorator

@app.route('/')
#def index():
 #   return render_template('index.html')
def index():
    conn = get_db_connection()
    users = conn.execute('SELECT * FROM users').fetchall()
    professions = conn.execute('SELECT * FROM professions').fetchall()
    cvs = conn.execute('SELECT * FROM CV').fetchall()
    conn.close()
    return render_template('index.html', users=users, professions=professions, cvs=cvs)
   # return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
       #if request.method == 'POST':

        username = request.form['username']
        password = request.form['password']
        user = validate_user(username, password)
        if user:
            session['user_id'] = user['id']
            session['user_role'] = user['role']
            return redirect(url_for('dashboard'))
           # else:
                #flash('Invalid username or password')
       #return render_template('login.html')

        return 'Invalid credentials'
        

def validate_user(username, password):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('SELECT id, role_id FROM users WHERE username = ? AND password = ?', (username, password))
    user = c.fetchone()
    conn.close()
    if user:
        return {'id': user[0], 'role': user[1]}
    return None

logging.basicConfig(level=logging.DEBUG)

@app.route('/dashboard')
#@login_required
def dashboard():
    #return render_template('dashboard.html', role=session['user_role'])
    #if 'user_id' not in session:
    #    return redirect(url_for('login'))
    app.logger.debug('Отладочная информация')
    #return render_template('dashboard.html', role=session['role'])
    return render_template('dashboard.html')



@app.route('/add_user', methods=['GET', 'POST'])
#@login_required
#@role_required('ADMIN')

def add_user():
    if request.method == 'POST':
        telegram_id = request.form['telegram_id']
        username = request.form['username']
        full_name = request.form['full_name']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        database.save_user(telegram_id, username, full_name, email, password, role)
        
        return redirect(url_for('dashboard'))
    return render_template('add_user.html')

@app.route('/add_profession', methods=['GET', 'POST'])

#@login_required
#@role_required('HR')

def add_profession():
    if request.method == 'POST':
        name = request.form['name']
        database.save_profession(name)
        return redirect(url_for('dashboard'))
    return render_template('add_profession.html')

@app.route('/add_cv', methods=['GET', 'POST'])
#@login_required
#@role_required('HR')

def add_cv():
    if request.method == 'POST':
        user_id = request.form['user_id']
        username = request.form['username']
        file_name = request.form['file_name']
        file_path = request.form['file_path']
        profession_id = request.form['profession_id']
        database.save_cv(user_id, username, file_name, file_path, profession_id)
        return redirect(url_for('dashboard'))
    return render_template('add_cv.html')

@app.route('/edit_user/<int:user_id>', methods=['GET', 'POST'])
#@login_required
#@role_required('ADMIN')

def edit_user(user_id):
    user = database.get_user(user_id)
    if request.method == 'POST':
        telegram_id = request.form['telegram_id']
        username = request.form['username']
        full_name = request.form['full_name']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        database.update_user(user_id, telegram_id, username, full_name, email, password,  role)
        return redirect(url_for('dashboard'))
    return render_template('edit_user.html', user=user)

@app.route('/edit_profession/<int:profession_id>', methods=['GET', 'POST'])
#@login_required
#@role_required('ADMIN')

def edit_profession(profession_id):
    profession = database.get_profession(profession_id)
    if request.method == 'POST':
        name = request.form['name']
        database.update_profession(profession_id, name)
        return redirect(url_for('dashboard'))
    return render_template('edit_profession.html', profession=profession)

@app.route('/edit_cv/<int:cv_id>', methods=['GET', 'POST'])
#@login_required
#@role_required('ADMIN')

def edit_cv(cv_id):
    cv = database.get_cv(cv_id)
    if request.method == 'POST':
        user_id = request.form['user_id']
        username = request.form['username']
        file_name = request.form['file_name']
        file_path = request.form['file_path']
        profession_id = request.form['profession_id']
        database.update_cv(cv_id, user_id, username, file_name, file_path, profession_id)
        return redirect(url_for('dashboard'))
    return render_template('edit_cv.html', cv=cv)
## 
## Показать все

# New routes to display IDs
@app.route('/users')
#@login_required
#@role_required('ADMIN')

def users():
    conn = get_db_connection()
    users = conn.execute('SELECT * FROM users').fetchall()
    conn.close()
    return render_template('users.html', users=users)

@app.route('/professions')
#@login_required
#@role_required('ADMIN')

def professions():
    conn = get_db_connection()
    professions = conn.execute('SELECT * FROM professions').fetchall()
    conn.close()
    return render_template('professions.html', professions=professions)

@app.route('/cvs')
#@login_required
#@role_required('ADMIN')

def cvs():
    conn = get_db_connection()
    cvs = conn.execute('SELECT * FROM CV').fetchall()
    conn.close()
    return render_template('cvs.html', cvs=cvs)



@app.route('/all_cv')
#@login_required
#@role_required('ADMIN')

def all_cv():
    conn = get_db_connection()
    cvs = conn.execute('SELECT * FROM CV').fetchall()
    conn.close()
    return render_template('all_cv.html', cvs=cvs)

@app.route('/all_professions')
#@login_required
#@role_required('ADMIN')

def all_professions():
    conn = get_db_connection()
    professions = conn.execute('SELECT * FROM professions').fetchall()
    conn.close()
    return render_template('all_professions.html', professions=professions)

@app.route('/all_users')
#@login_required
#@role_required('ADMIN')

def all_users():
    conn = get_db_connection()
    users = conn.execute('SELECT * FROM users').fetchall()
    conn.close()
    return render_template('all_users.html', users=users)


if __name__ == '__main__':
    #app.run(debug=True)
    port = int(os.environ.get("PORT", 8080))
    #app.run(host='0.0.0.0', port=8080)
    app.run(host='0.0.0.0', port=port)


