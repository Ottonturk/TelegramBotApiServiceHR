1.version:
$python --version

Python 3.7.2

2. db: sqlLite

3 pyTelegramBotApi:

pip show
pip list

http://127.0.0.1:5000/