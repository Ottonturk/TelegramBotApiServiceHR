import sqlite3

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    #Создание таблицы для ролей и добавление связи между пользователями и ролями.
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT UNIQUE NOT NULL
    )
    ''')

    
    # Создаем таблицу пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER,
            username TEXT,
            full_name TEXT,
            email TEXT,
            password TEXT,
            role_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (role_id) REFERENCES roles(id)
            
        )
    ''')
    
    # Создаем таблицу профессий
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS professions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT
        )
    ''')

    # Создаем таблицу резюме
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cv (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT,
            file_name TEXT,
            file_path TEXT,
            profession_id INTEGER,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (profession_id) REFERENCES professions (id)
        )
    ''')

    conn.commit()
    conn.close()

def save_cv(user_id, username, file_name, file_path, profession_id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO cv (user_id, username, file_name, file_path, profession_id)
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, username, file_name, file_path, profession_id))
    
    conn.commit()
    conn.close()

def save_user(telegram_id, username, full_name, email, password, role):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO users (telegram_id, username, full_name, email, password, role_id)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (telegram_id, username, full_name, email, password, role))
    
    conn.commit()
    conn.close()

def save_profession(name):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO professions (name)
        VALUES (?)
    ''', (name,))
    
    conn.commit()
    conn.close()


def get_user(telegram_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        SELECT * FROM users WHERE id = ?
    ''', (telegram_id,))
    user = c.fetchone()
    conn.close()
    return user

def get_profession(profession_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        SELECT * FROM professions WHERE id = ?
    ''', (profession_id,))
    profession = c.fetchone()
    conn.close()
    return profession

def get_cv(cv_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        SELECT * FROM CV WHERE id = ?
    ''', (cv_id,))
    cv = c.fetchone()
    conn.close()
    return cv

def update_user(user_id, telegram_id, username, full_name, email, password, role):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        UPDATE users
        SET telegram_id = ?, username = ?, full_name = ?, email = ?, password = ?, role_id = ?
        WHERE id = ?
   
    ''', (telegram_id, username, full_name, email, password, role, user_id))
    
    conn.commit()
    conn.close()

def update_profession(profession_id, name):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        UPDATE professions
        SET name = ?
        WHERE id = ?
    ''', (name, profession_id))
    conn.commit()
    conn.close()

def update_cv(cv_id, user_id, username, file_name, file_path, profession_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        UPDATE CV
        SET user_id = ?, username = ?, file_name = ?, file_path = ?, profession_id = ?
        WHERE id = ?
    ''', (user_id, username, file_name, file_path, profession_id, cv_id))
    conn.commit()
    conn.close()


def add_role(role_name):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('INSERT INTO roles (role_name) VALUES (?)', (role_name,))
    conn.commit()
    conn.close()

def get_role_id(role_name):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('SELECT id FROM roles WHERE role_name = ?', (role_name,))
    role_id = c.fetchone()
    conn.close()
    return role_id[0] if role_id else None



# Initialize roles ( вынести потом в отдеьные методы наполнения так как уникальные знгачения)
#add_role('ADMIN')
#add_role('HR')
