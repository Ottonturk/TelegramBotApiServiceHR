import database

# Инициализация базы данных
database.init_db()

# Тестовые данные для пользователей
test_users = [
    {'telegram_id': 220583117, 'username': 'ottonturk', 'full_name': 'Tim SH', 'email': 'lannister1989@yandex.ru', 'password': '123456#', 'role_id': '1'},
    {'telegram_id': 220583118, 'username': 'ottonturk2', 'full_name': 'Tim SH N', 'email': '12345test21234567890@yandex.ru.com', 'password': '123456#', 'role_id': '1'},
]

# Тестовые данные для профессий
test_professions = [
    {'name': 'Software Developer'},
    {'name': 'Data Scientist'},
]

# Тестовые данные для CV
test_cvs = [
    {'user_id': 1, 'username': 'user1', 'file_name': 'cv_user1.pdf', 'file_path': 'CV/cv_user1.pdf', 'profession_id': 1},
    {'user_id': 2, 'username': 'user2', 'file_name': 'cv_user2.pdf', 'file_path': 'CV/cv_user2.pdf', 'profession_id': 2},
]

# Функция для тестирования добавления пользователей
def test_add_users(users):
    for user in users:
        try:
            database.save_user(user['telegram_id'], user['username'], user['full_name'], user['email'], user['password'], user['role_id'])
            print(f"Пользователь {user['username']} успешно добавлен.")
        except Exception as e:
            print(f"Ошибка при добавлении пользователя {user['username']}: {e}")

# Функция для тестирования добавления профессий
def test_add_professions(professions):
    for profession in professions:
        try:
            database.save_profession(profession['name'])
            print(f"Профессия {profession['name']} успешно добавлена.")
        except Exception as e:
            print(f"Ошибка при добавлении профессии {profession['name']}: {e}")

# Функция для тестирования добавления CV
def test_add_cvs(cvs):
    for cv in cvs:
        try:
            database.save_cv(cv['user_id'], cv['username'], cv['file_name'], cv['file_path'], cv['profession_id'])
            print(f"CV {cv['file_name']} успешно добавлено.")
        except Exception as e:
            print(f"Ошибка при добавлении CV {cv['file_name']}: {e}")

# Тестирование добавления пользователей
test_add_users(test_users)

# Тестирование добавления профессий
test_add_professions(test_professions)

# Тестирование добавления CV
test_add_cvs(test_cvs)

