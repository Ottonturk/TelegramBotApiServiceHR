
import sqlite3

def connect_db():
    return sqlite3.connect('database.db')

def update_cv(cv_id, user_id=None, username=None, file_name=None, file_path=None, profession_id=None):
    conn = connect_db()
    cursor = conn.cursor()

    query = "UPDATE CV SET "
    parameters = []
# присвоение id-ников таблице CV:
    if user_id is not None:
        query += "user_id = ?, "
        parameters.append(user_id)
    if username is not None:
        query += "username = ?, "
        parameters.append(username)
    if file_name is not None:
        query += "file_name = ?, "
        parameters.append(file_name)
    if file_path is not None:
        query += "file_path = ?, "
        parameters.append(file_path)
    if profession_id is not None:
        query += "profession_id = ?, "
        parameters.append(profession_id)

    query = query.rstrip(", ")  # Удаление последней запятой и пробела
    query += " WHERE id = ?"
    parameters.append(cv_id)

    cursor.execute(query, parameters)
    conn.commit()
    conn.close()

def update_user(user_id, username=None, full_name=None, email=None, password=None, role_id=None):
    conn = connect_db()
    cursor = conn.cursor()

    query = "UPDATE users SET "
    parameters = []

    if username is not None:
        query += "username = ?, "
        parameters.append(username)
    if full_name is not None:
        query += "full_name = ?, "
        parameters.append(full_name)
    if email is not None:
        query += "email = ?, "
        parameters.append(email)
    if password is not None:
        query += "password = ?, "
        parameters.append(password)
    if role_id is not None:
        query += "role_id = ?, "
        parameters.append(role_id)
    query = query.rstrip(", ")  # Удаление последней запятой и пробела
    query += " WHERE id = ?"
    parameters.append(user_id)

    cursor.execute(query, parameters)
    conn.commit()
    conn.close()

def update_profession(profession_id, name):
    conn = connect_db()
    cursor = conn.cursor()

    query = "UPDATE professions SET name = ? WHERE id = ?"
    cursor.execute(query, (name, profession_id))

    conn.commit()
    conn.close()
