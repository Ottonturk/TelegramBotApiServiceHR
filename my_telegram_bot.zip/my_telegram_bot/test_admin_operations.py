import admin_operations

def test_update_cv():
    print("Testing update_cv...")
    try:
        admin_operations.update_cv(cv_id=1, user_id=220583117, username="ottonturk", file_name="6563018.pdf", file_path="/CV/6563018.pdf", profession_id='')
        print("update_cv passed")
    except Exception as e:
        print(f"update_cv failed: {e}")

def test_update_user():
    print("Testing update_user...")
    try:
        admin_operations.update_user(user_id=1, username="ottonturk", full_name="Tomy hilfiger", email="Tomyhilfiger@yandex.ru", password="123456#", role_id="1")
        print("update_user passed")
    except Exception as e:
        print(f"update_user failed: {e}")

def test_update_profession():
    print("Testing update_profession...")
    try:
        admin_operations.update_profession(profession_id=2, name="Technical Architect")
        print("update_profession passed")
    except Exception as e:
        print(f"update_profession failed: {e}")

if __name__ == "__main__":
    test_update_cv()
    test_update_user()
    test_update_profession()


